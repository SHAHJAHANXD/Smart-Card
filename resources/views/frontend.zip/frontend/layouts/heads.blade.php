<meta charset="utf-8" />
<meta http-equiv="x-ua-compatible" content="ie=edge" />
<meta name="description" content="" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta property="og:title" content="" />
<meta property="og:type" content="" />
<meta property="og:url" content="" />
<meta property="og:image" content="" />
<!-- Favicon -->
<link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets') }}/imgs/theme/favicon.html" />

<!-- Template CSS -->
<link rel="stylesheet" href="{{ asset('assets') }}/css/plugins/animate.min.html" />
<link rel="stylesheet" href="{{ asset('assets') }}/css/main8c94.css?v=4.1" />
<link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
